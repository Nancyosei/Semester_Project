#include <iostream>
#include <string>

using namespace std;

int main() {
    string again;
    cout << "Welcome to our humble hotel platform"<<endl;
    cout<< "======================================\n\n";
    do{
    cout << "Please how may i assist you?"<<endl;

    cout << "1. Check-in "<<endl;
    cout << "2. check-out "<<endl;
    cout << "3. Request for room maintenance"<<endl;
    cout << "4. Exit\n\n";

    cout << "Please enter the number of your choice: ";
    int choice;
    cin >> choice;

    if(choice == 1){
        cout<< "You are once again welcome to our hotel\n\n";

        cout << "Enter your name:"<<endl;
        string name;
        cin >> name;

        cout << "enter your age:"<<endl;
        int age;
        cin>>age;

        cout<< "Enter your phone number:"<<endl;
        int number;
        cin>>number;

        cout<< "Enter your gender(M/F)"<<endl;
        char gender;
        cin>>gender;

        cout << "Please we have VIP and VVIP which one do you prefer?"<<endl;
        cout << "1. VIP"<<endl;
        cout << "2. VVIP"<<endl;

        cout << "Please enter the number of your choice: ";
        int choice;
        cin >> choice;

        if(choice == 1){
            cout << "The price for a VIP room for a day is GHC 100.00"<<endl;

            cout << "How many days do you prefer to stay?"<<endl;
            int days;
            cin >> days;

            int cal = days * 100;
            cout << "You will pay GHC "<<cal<< ".00\n\n";

            cout << "Please make your payment through this line 0595010368"<<endl;
            cout << "PLease sign your signature here:\n\n";

            cout << "You have successfully booked a VIP room\n\n";

        }
        else if(choice == 2){
            cout << "The price for a VVIP room for a day is GHC 300.00"<<endl;

            cout << "How many days do you prefer to stay?"<<endl;
            int days;
            cin >> days;

            int cal = days * 200;
            cout << "You will pay GHC "<<cal<< ".00\n\n";

            cout << "Please make your payment through this line 0595010368"<<endl;
            cout << "PLease sign your signature here:\n\n";

            cout << "You have successfully booked a VVIP room\n\n";
            cout << "Don't forget you have access to swimming pool,restaurant,gym\n\n";
            cout << "Please enjoy your stay!\n\n";

    }
    }
    else if(choice == 2){
        cout << "Please record your time:"<<endl;
        int time;
        cin>> time;

        cout<< "Please provide your signature here"<<endl;
        cout << "Summit your keys \n\n";
        cout << "You have successfully checked-out\n";
        cout << "Hope to see you again!\n\n";
    }
    else if(choice == 3){
        cout<< "A room assistant will be there in a minute\n";
        cout << "Are you satisfy with your results(Y\N)?\n";
        char choice;
        cin >> choice;
        if(choice == 'Y' || 'y'){
            cout << "Happy you are satisfied!\n";
        }
        else if(choice == 'N' || 'n'){
            cout<< "Sorry for any inconvenience \n";
            cout << "Another assistant will be there soon\n\n";
        }
        else {
            cout << "Your input is incorrect, try again!\n\n";
        }

    }
    else if(choice == 4){
        cout << "You have exited the App successfully!"<<endl;
    }
     else{
        cout << "Your input is incorrect, try again!\n\n";

    }
    cout << "Are you satisfy with your request?"<<endl;
    cin >> again;
    cout << "\n";
    }
    while(again == "No" || again == "no");
    cout << "Thank you for visiting us!"<<endl;


    return 0;
    }
